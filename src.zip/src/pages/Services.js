// Home.js
import React from "react";

const Services = () => {
  return (
    <div class="page">
      <h2>Welcome to the Services Page</h2>
    </div>
  );
};

export default Services;
